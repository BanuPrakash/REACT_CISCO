"use client";

import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';

import type Product from '../../model/Product'
import Link from 'next/link';
import Image from 'next/image';


type AppProps = {
  product: Product
}

export default function ProductCard({product}: AppProps) {
  let {id, title, image, price} = product;

  return (
  <div className='col-md-4'>
    <Card style={{ width: '18rem' }}>
      <Link href={`/products/${id}`}>
        {/* <Card.Img variant="top" src={image} /> */}
         <Image
              src={image}
              alt={title}
  
               height={400}
               width={400}
           
              className="opacity-100 group-hover:opacity-20 transition-opacity duration-300 rounded-t-lg"
            />
      </Link>
      
      <Card.Body>
        <Card.Title>{title}</Card.Title>
      </Card.Body>
      <Card.Footer>
        Rs. {price} &nbsp;&nbsp;&nbsp;&nbsp;   
        <Button variant="primary">Add</Button>
      </Card.Footer>
    </Card>
  </div>
   
  )
}
