import Product from "@/model/Product";

export default async function Details({
    params,
}: {
    params: Promise<{ id: string }>;
}) {
    let { id } = await params; // PathVariable, Path Parameter
    const res = await fetch("https://fakestoreapi.com/products/" + id);
    const product: Product = await res.json();

    return (
        <div>
            Details
            {product && <div>
                Title: {product.title} <br />
                <img src={product.image} />
            </div>
            }
        </div>
    )
}
