import ProductCard from "@/components/products/ProductCard";
import Product from "@/model/Product";

export default async function Products() {
  const res = await fetch("https://fakestoreapi.com/products?limit=5");
  const products:Product[] = await res.json();

  return (
     <div className="container">
        <div className="row">
            {
            products && products.map(product => <ProductCard key={product.id} product={product} />)
          }
        </div>
       </div>
  );
}